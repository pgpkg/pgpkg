--
-- Tests that the open_time setting is honoured. This is the opening time for
-- transactions. A transaction posted before the open time is modified so that
-- it appears at the open time. When this happens, we also record the originally
-- requested time for the transaction.
--
create or replace function gl.test_tx_finalise_open_time() returns void language plpgsql as $$
declare
    _team_k gl.team_k;
    _tx_k gl.tx_k;
    _debtor_k gl.account_k;
    _sales1_k gl.account_k;
    _sales2_k gl.account_k;
    _tax_k gl.account_k;
    _disc_k gl.account_k;
    _tx_time timestamptz;
    _item_time timestamptz;
    _open_time timestamptz;

begin
    _team_k = gl.team_create('Test team');
    _debtor_k = gl.debtor_create(_team_k, 'Test Creditor #1');

    _tx_time = '2000-1-1 00:00:00+0'; -- current_timestamp - '1 month'::interval;
    _open_time = '2000-2-1 00:00:00+0'; -- current_timestamp;
    _item_time = '2000-3-1 00:00:00+0'; -- current_timestamp + '1 month'::interval;

    update gl.settings set opening_time = _open_time where team = _team_k;

    _sales1_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Test Sale #1', 99991);
    _sales2_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Test Sale #2', 99992);
    _tax_k = gl.account_create(_team_k, (gl.settings(_team_k)).liabilities, 'Test Tax #1', 99993);
    _disc_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Test Discount #1', 99994);

    _tx_k = gl.tx_create(_team_k, 'receipt', _debtor_k, gl.currency('USD'), _tx_time);
    perform gl.item_create(_team_k, _tx_k, _sales1_k, 100.0, 'Test item #1', null, array[(_tax_k, 5.123456), (_disc_k, 6), (_disc_k, 7)]::gl.adjustment_t[]);
    perform gl.item_create(_team_k, _tx_k, _sales2_k, 150.0, 'Test item #2', _item_time, array[(_tax_k, 5.123456), (_disc_k, 6), (_disc_k, 7)]::gl.adjustment_t[]);
    perform gl.tx_finalise(_team_k, _tx_k);

    -- entry time should be changed because tx.effective_time < settings.opening_time.
    perform effective_time =? _open_time, requested_time =? _tx_time, amount =? -286.24 from gl.entry where team=_team_k and account=_debtor_k;

    -- entry time should be changed because item.effective_time is null, but tx.effective_time < settings.opening_time.
    perform effective_time =? _open_time, requested_time =? _tx_time, amount =? 100 from gl.entry where team=_team_k and account=_sales1_k;

    -- entry time should not change because item.effective_time >= settings.opening_time.
    perform effective_time =? _item_time, ??(requested_time is null), amount =? 150 from gl.entry where team=_team_k and account=_sales2_k;
end;
$$;