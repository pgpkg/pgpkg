--
-- Ensures that we can add an entry on or after the opening_time, and that we cannot
-- add an entry before the opening_time.
--

--
-- Make sure we can add a transaction at exactly the opening time.
--
create or replace function gl.test_entry_opening_time() returns void language plpgsql as $$
declare
    _team_k gl.team_k;
    _tx_k gl.tx_k;
    _debtor_k gl.account_k;
    _item_account_k gl.account_k;
    _opening_time timestamptz;

    begin
        _team_k = gl.team_create('Test team');
        _debtor_k = gl.debtor_create(_team_k, 'Test Creditor #1');
        _opening_time = opening_time from gl.settings(_team_k);
        _item_account_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Sales account', 99993);

        -- The intent of this test is to test that entries are gated by the opening_time of a team's settings.
        -- So we can't use the usual functions, since those are already supposed to be working properly.
        _tx_k = gl.tx_create(_team_k, 'debit', _debtor_k, gl.currency('USD'));

        -- This should work.
        insert into gl.entry (team, entry, tx, account, effective_time, currency, amount)
            values (_team_k, default, _tx_k, _item_account_k, _opening_time, gl.currency('USD'), 100);
    end;
$$;

--
-- Make sure we can't add a transaction just before the opening time. This test traps the error
-- produced by attempting to insert an entry before the opening_time.
--
create or replace function gl.test_entry_opening_time_error() returns void language plpgsql as $$
    declare
        _team_k gl.team_k;
        _tx_k gl.tx_k;
        _debtor_k gl.account_k;
        _item_account_k gl.account_k;
        _opening_time timestamptz;
        _succeeded boolean = false;         -- we do not want this to become true.

    begin
        _team_k = gl.team_create('Test team');
        _debtor_k = gl.debtor_create(_team_k, 'Test Creditor #1');
        _opening_time = opening_time from gl.settings(_team_k);
        _item_account_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Sales account', 99993);

        -- The intent of this test is to test that entries are gated by the opening_time of a team's settings.
        -- So we can't use the usual functions, since those are already supposed to be working properly.
        _tx_k = gl.tx_create(_team_k, 'debit', _debtor_k, gl.currency('USD'));

        -- This should NOT work.
        insert into gl.entry (team, entry, tx, account, effective_time, currency, amount)
            values (_team_k, default, _tx_k, _item_account_k, _opening_time - '1 millisecond'::interval, gl.currency('USD'), 100);
        _succeeded = true;
        raise exception 'Insert into entry improperly succeeded when effective_time < opening_time';

    exception when raise_exception then
        if _succeeded then
            raise exception 'Insert into entry improperly succeeded when effective_time < opening_time';
        end if;
    end;
$$;