--
-- Finalise a transaction.
-- This takes the items and their adjustments and generates a bunch of Entries.
-- For performance and complexity reasons, we don't try to maintain a correspondence between
-- individual tx items and the entries they create. Instead, we sum the various accounts, and
-- post a single entry for each account, regardless of how many items it appears on.
-- Entries which have different effective_times are of course not stored together.
--

create or replace function gl.tx_finalise(_team_k gl.team_k, _tx_k gl.tx_k) returns void language plpgsql as $$
    declare
        _tx gl.tx;
        _item gl.item;
        _adjustment gl.adjustment_t;
        _item_amount decimal = 0;
        _tx_amount decimal = 0;
        _rounding_dps smallint;
        _rounding_account gl.account_k;
        _rounding decimal;
        _entry_k gl.entry_k;
        _open_item boolean;
        _sign decimal = 1;
        _effective_time timestamptz;
        _requested_time timestamptz;
        _entry gl.tx_entry_t;
        _item_entries gl.tx_entry_t[];
        _tx_entries gl.tx_entry_t[];
        _opening_time timestamptz = (gl.settings(_team_k)).opening_time;

    begin
        select * into strict _tx from gl.tx where team=_team_k and tx=_tx_k for update;

        -- Is this a credit or debit transaction, relative to tx.account (which is typically
        -- a debtor or creditor)? Note that the base value and all adjustments of a transaction
        -- are always positive values regardless of the transaction type. For transactions which
        -- are nominally debits, the item base value and adjustments are actually credits against
        -- the sales and other accounts. This means that the sign needs to be reversed relative to
        -- what we might expect.
        if gl.tx_isdebit(_tx.tx_type) then
            _sign = -1;
        else
            _sign = 1;
        end if;

        --
        -- Create a list of the set of GL entries that we intend to create for the tx.
        -- The entries correspond to the base item value and any adjustments, as well as
        -- the total item value which is to be applied to the transaction's account.
        -- Later, we will aggregate the values to remove duplicates and create the entries that we store.
        --
        for _item in select * from gl.item where team=_team_k and tx=_tx_k for update
        loop
            _effective_time = coalesce(_item.effective_time, _tx.effective_time);
            if array_length(_item.adjustments, 1) > 0 then
                -- Get total value of adjustments to the base amount, if any.
                _item_amount = _item.base + (select sum(amount) from unnest(_item.adjustments));

                -- Convert the adjustments to entries.
                for _adjustment in select * from unnest(_item.adjustments) loop
                    _item_entries = _item_entries || (_adjustment.account, _adjustment.amount, _effective_time)::gl.tx_entry_t;
                end loop;
            else
                _item_amount = _item.base;
            end if;
            _tx_amount = _tx_amount + _item_amount;

            -- Add an entry for the base value of the item.
            _item_entries = _item_entries || (_item.account, _item.base, _effective_time)::gl.tx_entry_t;
        end loop;

        -- Create an entry for the total value of the transaction, which will be applied to the transaction's account.
        -- The effective time in receivables/payables is always the transaction's effective time.
        -- Since all values in a tx are (nominally) positive, the sign of this "adjustment" is always negative.
        -- This is the entry that will be applied to receivables / payables.
        _item_entries = _item_entries || (_tx.account, -_tx_amount, _tx.effective_time)::gl.tx_entry_t;

        --
        -- Perform any necessary rounding on the entries before applying them.
        --
        for _entry in select account, sum(amount), effective_time from unnest(_item_entries) group by account, effective_time order by account, effective_time
            loop
                select rounding_dps, rounding_account into strict _rounding_dps, _rounding_account from gl.account where team=_team_k and account=_entry.account;
                if _rounding_dps is not null then
                    _rounding = _entry.amount - round(_entry.amount, _rounding_dps);
                    if _rounding <> 0 then
                        _tx_entries = _tx_entries || (_rounding_account, _rounding, _entry.effective_time)::gl.tx_entry_t;
                        _entry.amount = round(_entry.amount - _rounding, _rounding_dps);
                    else
                        -- reduce the number of trailing zeros without changing the value.
                        _entry.amount = round(_entry.amount, _rounding_dps);
                    end if;
                end if;
                _tx_entries = _tx_entries || _entry;
            end loop;

        --
        -- Summarise the entries by account, and create gl.entries against the tx.
        --
        for _entry in select account, sum(amount), effective_time from unnest(_tx_entries) group by account, effective_time
            loop
                if _entry.amount is not null and _entry.amount <> 0 then
                    _effective_time = _entry.effective_time;
                    if _effective_time < _opening_time then
                        _requested_time = _effective_time;
                        _effective_time = _opening_time;
                    else
                        _requested_time = null;
                    end if;

                    insert into gl.entry (team, tx, requested_time, effective_time, account, currency, amount)
                        values (_team_k, _tx_k, _requested_time, _effective_time, _entry.account, _tx.currency, _entry.amount * _sign)
                        returning entry into _entry_k;

                    select open_item into _open_item from gl.account where team=_team_k and account=_entry.account;
                    if _open_item then
                        insert into gl.unallocated (team, entry, currency, amount) values (_team_k, _entry_k, _tx.currency, _entry.amount * _sign);
                    end if;

                end if;
            end loop;

        update gl.tx set finalised_time=current_timestamp, amount=_tx_amount where team=_team_k and tx=_tx_k;
    end;
$$;

--
-- Useful function for debugging things as they happen.
--
create or replace function gl.print_adjustments(_team_k gl.team_k, _msg text, _adjustments gl.adjustment_t[]) returns void language plpgsql as $$
    declare
        _adjustment gl.adjustment_t;
        _name text;
        _total decimal = 0;

    begin
        raise notice '--';
        for _adjustment in select * from unnest(_adjustments) order by account
            loop
            _name = name from gl.account where team=_team_k and account=_adjustment.account;
            raise notice '%: adjustment [%] % amount %', _msg, _adjustment.account, rpad(_name, 20), _adjustment.amount;
            _total = _total + _adjustment.amount;
        end loop;
        raise notice 'total adjustments %', _total;
    end;
$$;