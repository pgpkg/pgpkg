--
-- Configures a new team, by setting up a complete chart of accounts for it.
-- Note: currency is going to disappear.
--
create or replace function gl.team_create(_name text, _team_k gl.team_k default gen_random_uuid()) returns gl.team_k language plpgsql as $$
    declare
        -- Income accounts
        ACIncome gl.account_k = 10000;
        ACSales gl.account_k = 11000;
        ACSurcharges gl.account_k = 12000;
        ACRounding gl.account_k = 13000;
        ACSalesRounding gl.account_k = 13001;
        ACTaxRounding gl.account_k = 13002;
        ACDiscountRounding gl.account_k = 13003;
        ACItemRounding gl.account_k = 13004;
        ACDebtorRounding gl.account_k = 13005;
        ACCredits gl.account_k = 14000;
        ACDebits gl.account_k = 15000;

        -- Expense accounts
        ACExpenses gl.account_k = 20000;
        ACDiscounts gl.account_k = 21000;
        ACCOGS gl.account_k = 22000;

        -- Assets
        ACAssets gl.account_k = 30000;
        ACReceivables gl.account_k = 31000;
        ACPaymentProcessors gl.account_k = 32000;
        ACStripe gl.account_k = 32100;
        ACAdyen gl.account_k = 32200;
        ACBank gl.account_k = 33000;

        -- Liabilities
        ACLiabilities gl.account_k = 40000;
        ACTax gl.account_k = 41000;
        ACSalesTaxCollected gl.account_k = 41100;

        -- Equity
        ACEquity gl.account_k = 50000;

    begin
        insert into gl.team (team, name) values (_team_k, _name);

        perform gl.account_create(_team_k, null, 'Income', ACIncome);
        perform gl.account_create(_team_k, ACIncome, 'Credit Notes', ACCredits);
        perform gl.account_create(_team_k, ACIncome, 'Debit Notes', ACDebits);
        perform gl.account_create(_team_k, ACIncome, 'Sales', ACSales);
        perform gl.account_create(_team_k, ACIncome, 'Surcharges', ACSurcharges);

        perform gl.account_create(_team_k, null, 'Assets', ACAssets);
        perform gl.account_create(_team_k, ACAssets, 'Accounts Receivable', ACReceivables);
        perform gl.account_create(_team_k, ACAssets, 'Payment Processors', ACPaymentProcessors);
        perform gl.account_create(_team_k, ACPaymentProcessors, 'Stripe', ACStripe);
        perform gl.account_create(_team_k, ACPaymentProcessors, 'Adyen', ACAdyen);
        perform gl.account_create(_team_k, ACAssets, 'Bank Accounts', ACBank);
        perform gl.account_create(_team_k, ACAssets, 'Rounding', ACRounding);
        perform gl.account_create(_team_k, ACRounding, 'Sales Rounding', ACSalesRounding);
        perform gl.account_create(_team_k, ACRounding, 'Item Rounding', ACItemRounding);
        perform gl.account_create(_team_k, ACRounding, 'Debtor Rounding', ACDebtorRounding);
        perform gl.account_create(_team_k, ACRounding, 'Tax Rounding', ACTaxRounding);
        perform gl.account_create(_team_k, ACRounding, 'Discount Rounding', ACDiscountRounding);

        perform gl.account_create(_team_k, null, 'Expenses', ACExpenses);
        perform gl.account_create(_team_k, ACExpenses, 'Discounts given', ACDiscounts, 2, ACDiscountRounding);
        perform gl.account_create(_team_k, ACExpenses, 'Cost of sales', ACCOGS);

        perform gl.account_create(_team_k, null, 'Liabilities', ACLiabilities);
        perform gl.account_create(_team_k, ACLiabilities, 'Tax', ACTax);
        perform gl.account_create(_team_k, ACLiabilities, 'Sales Tax Collected', ACSalesTaxCollected, 2, ACTaxRounding);

        perform gl.account_create(_team_k, null, 'Equity', ACEquity);


        insert into gl.settings
            (team, reporting_timezone, reporting_cycle_start, opening_time,
             assets, liabilities, tax, income, sales, expenses,
             receivables, credits, debits, item_rounding, debtor_rounding)
            values (_team_k, 'Australia/Melbourne', '2000-7-1', '2023-01-01 00:00:00+0',
                    ACAssets, ACLiabilities, ACTax, ACIncome, ACSales, ACExpenses,
                    ACReceivables, ACCredits, ACDebits, ACItemRounding, ACDebtorRounding);

        return _team_k;
    end;
$$;