--
-- This trigger ensures that the entry currency always matches the tx currency,
-- and is on or after the opening_time.
--
-- It is critical to ensure that entry currencies do not vary from the tx.
--
-- If you need to post an entry that is dated before the opening_time, set entry.requested_time to the
-- original opening_time, and set effective_time to opening_time. Of course, the trigger could do this
-- change automatically, but it may be confusing if we adjust entries silently in the trigger.
--
create or replace function gl.entry_trigger() returns trigger language plpgsql as $$
    declare
        _currency gl.currency_t;
        _opening_time timestamptz;

    begin
        _currency = currency from gl.tx where team=NEW.team and tx=NEW.tx;
        if _currency <> NEW.currency then
            raise exception 'entry % currency % does not match tx % currency %', NEW.entry, NEW.currency, NEW.tx, _currency;
        end if;

        _opening_time = opening_time from gl.settings(NEW.team);
        if NEW.effective_time < _opening_time then
            raise exception 'entry % effective_time % is before opening_time %', NEW.entry, NEW.effective_time, _opening_time;
        end if;

        return NEW;
    end;
$$;

create or replace trigger currency_trigger
    before insert or update
    on gl.entry
    for each row
    execute procedure gl.entry_trigger();

--
-- Useful function for debugging things as they happen.
--
create or replace function gl.print_entries(_team_k gl.team_k, _msg text, _tx_k gl.tx_k) returns void language plpgsql as $$
declare
    _entry gl.entry;
    _name text;
    _total decimal = 0;
begin
    raise notice '--';
    for _entry in select * from gl.entry where team=_team_k and tx=_tx_k order by account
        loop
            _name = name from gl.account where team=_team_k and account=_entry.account;
            raise notice '%: entry [%] % amount %', _msg, _entry.account, rpad(_name, 20), _entry.amount;
            _total = _total + _entry.amount;
        end loop;
    raise notice 'total adjustments %', _total;
end;
$$;