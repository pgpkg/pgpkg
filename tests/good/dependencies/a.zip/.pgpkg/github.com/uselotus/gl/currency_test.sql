--
-- Test that currency conversions work properly.
--
create or replace function gl.test_currency() returns void language plpgsql as $$
    begin
        perform gl.currency('AAA') =? 0;
        perform gl.currency('ZZZ') =? 17575;
        perform gl.currency('USD') =? 13991;
        perform gl.currency('AUD') =? 523;
        perform gl.currency('EUR') =? 3241;
        perform gl.currency('CAD') =? 1355;
        perform gl.currency('CNY') =? 1714;
        perform gl.currency('INR') =? 5763;

        perform gl.currency(0) =? 'AAA';
        perform gl.currency(17575) =? 'ZZZ';
        perform gl.currency(13991) =? 'USD';
        perform gl.currency(523) =? 'AUD';
        perform gl.currency(3241) =? 'EUR';
        perform gl.currency(1355) =? 'CAD';
        perform gl.currency(1714) =? 'CNY';
        perform gl.currency(5763) =? 'INR';
    end;
$$;