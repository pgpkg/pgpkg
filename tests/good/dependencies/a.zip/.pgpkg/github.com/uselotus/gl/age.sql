--
-- Compute the age of a transaction, in units of 30 days.
-- We might need to improve this function later to take different ageing policies into
-- account.
--
create or replace function gl.age(_time timestamptz, _since timestamptz default current_timestamp) returns integer language sql stable as $$
    select round(extract(day from (_since - _time)) / 30, 0) * 30;
$$;