--
-- Test that debit notes work.
--

create or replace function gl.test_debit_create() returns void language plpgsql as $$
    declare
        _team_k gl.team_k;
        _debtor_k gl.account_k;
        _message text;
        _debit_k gl.tx_k;

    begin
        _team_k = gl.team_create('Test team');
        _debtor_k = gl.debtor_create(_team_k, 'Test Debtor #1');
        _message = 'Test debit #' || _debtor_k;
        _debit_k = gl.debit_create(_team_k, _debtor_k, gl.currency('AUD'), 100.0, _message);

        -- debtor's balance should be in debit.
        perform count(*) =? 1, coalesce(sum(amount), 0) =? 100 from gl.aged_balance(_team_k, gl.currency('AUD'), _debtor_k);

        -- exactly one entry in receivables...
        perform gl.currency(currency) =? 'AUD', amount =? 100 from gl.entry where team=_team_k and account=_debtor_k;

        -- ...and one more in the credit account
        perform gl.currency(currency) =? 'AUD', amount =? -100 from gl.entry where team=_team_k and account=((gl.settings(_team_k)).debits);

        -- ...and one item against the transaction, with the right message.
        perform amount =? 100, message.message =? _message strict from gl.item
            join gl.message on (message.team = item.team and message.hash = item.description)
            where item.team=_team_k and tx=_debit_k;

        -- and make sure there's an allocation.
        perform unallocated.amount =? 100, unallocated.currency = gl.currency('AUD')
            from gl.unallocated join gl.entry using (team, entry) where team = _team_k and account=_debtor_k;
    end;
$$;