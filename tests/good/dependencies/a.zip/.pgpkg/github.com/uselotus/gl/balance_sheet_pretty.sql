--
-- Produces a nicely formatted balance sheet (nicely formatted for SQL, anyway).
--
create or replace function gl.balance_sheet_pretty(_team_k gl.team_k, _currency gl.currency_t, _depth integer)
    returns table (name text, currency text, amount decimal) language sql as $$
        select gl.account_pretty(account) || ' ' || lpad('', depth * 2 - 2) || name, gl.currency(currency), amount from gl.balance_sheet(_team_k, _currency, _depth);
$$;

--
-- Prints a nicely formatted balance sheet to the console. Very helpful when testing.
--
create or replace function gl.balance_sheet_notice(_team_k gl.team_k, _currency gl.currency_t, _depth integer) returns void language plpgsql as $$
    declare
        _name text;
        _amount decimal;

    begin
        for _name, _amount in select name, amount from gl.balance_sheet_pretty(_team_k, _currency, _depth)
        loop
            raise notice '% | %', rpad(_name, 20), lpad(coalesce(_amount::text, ''), 10);
        end loop;
    end;
$$;