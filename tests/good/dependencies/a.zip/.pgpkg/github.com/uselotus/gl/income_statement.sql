create or replace function gl.income_statement(_team_k gl.team_k, _currency gl.currency_t, _depth integer)
    returns table (team gl.team_k, account gl.account_k, parents gl.account_k[], depth integer, name text, reporting_period date, currency text, amount decimal) language plpgsql as $$
declare
    _bases gl.account_k[] = array[(gl.settings(_team_k)).income, (gl.settings(_team_k)).expenses];

begin
    -- Income
    create temp table incstmt as
    select account.team, account.account, account.parents, account.name, s.currency, s.reporting_period, sum(s.amount) as amount
        from gl.summarize(_team_k, _currency, _depth, true, _bases[1], -1) s join gl.account using (team, account)
        group by account.team, account.account, account.parents, account.name, s.currency, s.reporting_period;

    -- Expenses
    insert into incstmt
    select account.team, account.account, account.parents, account.name, s.currency, s.reporting_period, sum(s.amount) as amount
        from gl.summarize(_team_k, _currency, _depth, true, _bases[2], 1) s join gl.account using (team, account)
        group by account.team, account.account, account.parents, account.name, s.currency, s.reporting_period;

    -- Include parent accounts
    insert into incstmt (team, account, parents, name, currency)
    select account.team, account.account, account.parents, account.name, _currency
        from gl.account
        where
                account.team = _team_k and
                account.parents[1] = any(_bases) and
                account.parents not in (select incstmt.parents from incstmt);

    return query
        select incstmt.team, incstmt.account, incstmt.parents, array_length(incstmt.parents, 1), incstmt.name, incstmt.reporting_period, gl.currency(incstmt.currency), sum(incstmt.amount)
            from incstmt group by 1, 2, 3, 4, 5, 6, 7 order by 3, 5;

    drop table incstmt;
end;
$$;