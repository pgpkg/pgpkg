--
-- tx_entry_t is a date type used in TX finalisation to group together all adjustments from a tx.
-- It's basically the same as an adjustment but also contains timestamp information.
-- Note that a transaction can only occur in a single currency, so that's not part of this
-- object definition.
--
create type gl.tx_entry_t as (
    account        gl.account_k,
    amount         decimal,
    effective_time timestamptz
);