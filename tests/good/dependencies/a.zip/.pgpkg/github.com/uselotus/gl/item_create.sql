--
-- Add an item to an existing transaction.
-- You can include adjustments directly with this call or
-- we might add an item_adjust() function later to let it be done stepwise.
--

--     team           gl.team_k    not null,
--     item           gl.item_k    not null default gen_random_uuid(),
--     tx             gl.tx_k      not null,
--     effective_time timestamptz,                    -- defaults to the transaction's effective_time
--     description    uuid,
--
--     account        gl.account_k not null,
--     base           decimal      not null,          -- base value of this item before adjustments.
--     adjustments    gl.adjustment_t[],              -- The bits that make up this item.
--     amount         decimal      not null default 0 -- NOTE: Updated only by a trigger


create or replace function gl.item_create(_team_k gl.team_k, _tx_k gl.tx_k, _account_k gl.account_k, _base decimal, _description text, _effective_time timestamptz default null, _adjustments gl.adjustment_t[] default null) returns gl.item_k language plpgsql as $$
    declare
        _item_k gl.item_k;

    begin
        insert into gl.item (team, tx, account, description, base, effective_time, adjustments)
          values (_team_k, _tx_k, _account_k, gl.message(_team_k, _description), _base, _effective_time, _adjustments)
            returning item into _item_k;
        return _item_k;
    end;
$$;