--
-- Formats an account number in a standard way.
-- GL accounts are heirarchical and the usual practice is to create the hierarchy using a numerical
-- system, so that the first digit is the top (outermost) level, the second digit is the second level,
-- etc. However this means there's a limit of ten items per level, which obviously breaks down with
-- certain kinds of account.
--
-- (Note that this hierarchy is not built in; it's just a convention. The actual relationship between
-- account is established by account.parents).
--
-- To resolve this in a visually appealing way, we create account numbers where the first five digits refer
-- to a structural account the optional next nine digits refer to the leaves.
--
-- Examples include:
--
-- 10000           Income
-- 11000             Sales
-- 11000-000000060     Setup Fees
--
-- 30000           Assets
-- 31000             Receivables
-- 31000-000020521     Doctor Jane Smith from Chicago (31000-000020521)
--
-- This function simply formats an account number using this convention.
--
create or replace function gl.account_pretty(_account_k gl.account_k) returns text language sql as $$
    select case
           when _account_k <= 99999 then rpad(_account_k::text, 15)
           else substr(_account_k::text, 1, 5) || '-' || substr(_account_k::text, 6)
           end;
$$;