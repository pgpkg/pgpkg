--
-- This is a statement view. Unallocated is null if there is no allocation for a given entry.
--

--
-- Returns the statement for a debtor as at the current moment in time.
--
create or replace view gl.statement as
    select team, entry.entry, entry.account, entry.effective_time, gl.age(entry.effective_time) as age, tx.tx_type, entry.currency, entry.amount, unallocated.amount as unallocated
        from gl.entry
            join gl.account using (team, account)
            join gl.tx using (team, tx)
            left join gl.unallocated using (team, entry)
       order by effective_time desc;