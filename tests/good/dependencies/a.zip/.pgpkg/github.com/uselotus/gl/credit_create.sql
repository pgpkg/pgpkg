--
-- Simple function to add a credit to an account.
-- Since this is a double-entry system, a credit againts a debtor means we have to perform a debit somewhere else.
-- In this case, the account that is debited is defined by settings.credits, a credit-note account.
--
-- You should always pass a positive value to this function.
--
create or replace function gl.credit_create(_team_k gl.team_k, _credit_k gl.account_k, _currency gl.currency_t, _amount decimal, _comment text, _effective_time timestamptz default current_timestamp, _adjustments gl.adjustment_t[] default null) returns gl.tx_k language plpgsql as $$
    declare
        _tx_k gl.tx_k;
        _debit_k gl.account_k = (gl.settings(_team_k)).credits;

    begin
        perform _amount >=? 0;

        if _effective_time is null then
            _effective_time = current_timestamp;
        end if;

        _tx_k = gl.tx_create(_team_k, 'credit', _credit_k, _currency, _effective_time);
        perform gl.item_create(_team_k, _tx_k, _debit_k, _amount, _comment, null, _adjustments);
        perform gl.tx_finalise(_team_k, _tx_k);
        return _tx_k;
    end;
$$;