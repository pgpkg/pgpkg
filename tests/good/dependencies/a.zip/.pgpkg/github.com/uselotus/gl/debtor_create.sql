--
-- Creates a new debtor, which is a sub-account under the `receivables` account, found in settings.
-- The account numbers for debtors include the parent account suffixed with a large identifier. For example,
-- if the default receivables account is 31000, then the first debtor will be 31000-000000001.
--
-- Max bigint is 9223372036854775807 so assumng the first five digits are the account number, the max possible number
-- of debtors in this scheme is 72,036,854,775,807 which is expected to get us through the next year or two /s.
--
-- We use 9 digits for the debtor sub-ID to keep things managable, but this is a soft limit. The account number
-- uses a global sequence number.
--
-- If parent is null, then the parent account is the default receivables account.
--
create or replace function gl.debtor_create(_team gl.team_k, _name text, _parent gl.account_k default null) returns gl.account_k language plpgsql as $$
    declare
        _seq gl.account_k = nextval('gl.account_seq')::gl.account_k;
        _account_k gl.account_k;

    begin
        if _parent is null then
            _parent = (gl.settings(_team)).receivables;
        end if;

        _account_k = _parent * (10 ^ 9) + _seq;

        perform gl.account_create(_team, (gl.settings(_team)).receivables, _name, _account_k,
            2, (gl.settings(_team)).debtor_rounding, true);
        return _account_k;
    end;
$$;