create or replace function gl.test_account_pretty() returns void language plpgsql as $$
    begin
        perform gl.account_pretty(12345) =? '12345          ';
        perform gl.account_pretty(11000000002991) =? '11000-000002991';
    end;
$$;