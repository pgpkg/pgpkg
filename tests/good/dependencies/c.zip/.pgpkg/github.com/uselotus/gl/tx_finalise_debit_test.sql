--
-- Create a debit (invoice), and make sure the results make sense.
--
create or replace function gl.tx_finalise_debit(_team_k gl.team_k) returns void language plpgsql as $$
    declare
        _tx_k gl.tx_k;
        _debtor_k gl.account_k;
        _sales_k gl.account_k;
        _tax_k gl.account_k;
        _disc_k gl.account_k;

    begin
        perform gl.team_create('Test team ' || _team_k, _team_k);
        _debtor_k = gl.debtor_create(_team_k, 'Test Debtor #1');

        _tx_k = gl.tx_create(_team_k, 'invoice', _debtor_k, gl.currency('USD'), current_timestamp);

        _sales_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Test Sale #1', 99991);
        _tax_k = gl.account_create(_team_k, (gl.settings(_team_k)).liabilities, 'Test Tax #1', 99992);
        _disc_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Test Discount #1', 99993);

        perform gl.item_create(_team_k, _tx_k, _sales_k, 100, 'Test item #1', null, array[(_tax_k, 5.123456), (_disc_k, 6), (_disc_k, 7)]::gl.adjustment_t[]);

        perform gl.tx_finalise(_team_k, _tx_k);

        -- Assert the amounts we expect in each account
        perform sum(amount) =? 118.12 from gl.entry where team=_team_k and account=_debtor_k;
        perform sum(amount) =? -5.123456 from gl.entry where team=_team_k and account=_tax_k;
        perform sum(amount) =? -13.0 from gl.entry where team=_team_k and account=_disc_k;
        perform sum(amount) =? -100.0 from gl.entry where team=_team_k and account=_sales_k;
        perform sum(amount) =? 0.003456 from gl.entry where team=_team_k and account=13004;        -- rounding

        perform amount =? 118.12 from gl.tx where team=_team_k and tx=_tx_k;
    end;
$$;

-- Repeat the test 10 times with random team IDs to ensure no leakage between teams.
create or replace function gl.test_tx_finalise_debit() returns void language plpgsql as $$
    begin
        for i in 1 .. 10 loop
            perform gl.tx_finalise_debit(gen_random_uuid());
        end loop;
    end;
$$;