--
-- Generate an aged balance.
-- Note: aged balances only work for accounts with allocations.
-- Unallocated accounts will not appear in this view.
--
-- You can call this function with _account_k = null to get a report for all debtors.
--

create or replace function gl.aged_balance(_team_k gl.team_k, _currency_k gl.currency_t, _account_k gl.account_k default null, _since timestamptz default current_timestamp)
  returns table (team gl.team_k, account gl.account_k, age integer, max_age integer, currency gl.currency_t, count bigint, amount decimal)
    language sql as $$
        with stmt as (
          select
            entry.team,
            entry.entry,
            entry.account,
            entry.effective_time,
            gl.age(entry.effective_time, _since) as age,
            tx.tx_type,
            entry.currency,
            entry.amount,
            unallocated.amount as unallocated
          from gl.entry
            join gl.account using (team, account)
            join gl.tx using (team, tx)
            join gl.unallocated using (team, entry)
          where
            entry.team = _team_k and
            entry.currency = _currency_k and
            (_account_k is null or entry.account = _account_k)
        ) select stmt.team,
                stmt.account,
                least(stmt.age, 120)  as age,
                max(stmt.age)         as max_age,
                stmt.currency,
                count(*)         as count,
                sum(unallocated) as amount
            from stmt
                group by stmt.team, stmt.account, stmt.currency, least(stmt.age, 120)
                order by age;
$$;