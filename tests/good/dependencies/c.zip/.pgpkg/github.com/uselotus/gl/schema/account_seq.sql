--
-- This is a sequence number used to generate bulk account numbers
-- for use with debtors, creditors, etc.
--
create sequence gl.account_seq;