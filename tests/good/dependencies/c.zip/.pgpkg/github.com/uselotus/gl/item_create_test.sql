--
-- Test that we can create a transaction, add items to it and finalise it.
--

create or replace function gl.test_item_create() returns void language plpgsql as $$
    declare
        _team_k gl.team_k;
        _tx_k gl.tx_k;
        _debtor_k gl.account_k;
        _sales_k gl.account_k;
        _tax_k gl.account_k;
        _disc_k gl.account_k;

    begin
        _team_k = gl.team_create('Test team');
        _debtor_k = gl.debtor_create(_team_k, 'Test Debtor #1');

        _tx_k = gl.tx_create(_team_k, 'invoice', _debtor_k, gl.currency('USD'), current_timestamp);

        _sales_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Test Sale #1', 99991);
        _tax_k = gl.account_create(_team_k, (gl.settings(_team_k)).liabilities, 'Test Tax #1', 99992);
        _disc_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Test Discount #1', 99993);

        perform gl.item_create(_team_k, _tx_k, _sales_k, 100, 'Test item #1', null, array[(_tax_k, 5.123456), (_disc_k, 6), (_disc_k, 7)]::gl.adjustment_t[]);

        perform gl.tx_finalise(_team_k, _tx_k);

        -- Assert the amounts we expect in each account
        perform sum(amount) =? 118.12 from gl.entry where team=_team_k and account=_debtor_k;
        perform sum(amount) =? -5.123456 from gl.entry where team=_team_k and account=_tax_k;
        perform sum(amount) =? -13.0 from gl.entry where team=_team_k and account=_disc_k;
        perform sum(amount) =? -100.0 from gl.entry where team=_team_k and account=_sales_k;
        perform sum(amount) =? 0.003456 from gl.entry where team=_team_k and account=13004;        -- rounding

        perform amount =? 118.12 from gl.tx where team=_team_k and tx=_tx_k;

    end;
$$;