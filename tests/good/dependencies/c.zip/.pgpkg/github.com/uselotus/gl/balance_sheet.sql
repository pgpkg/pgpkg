--
-- Returns a table representing the balance sheet for a customer.
--
create or replace function gl.balance_sheet(_team_k gl.team_k, _currency gl.currency_t, _depth integer)
    returns table (team gl.team_k, account gl.account_k, name text, depth integer, currency gl.currency_t, amount decimal) language plpgsql as $$
declare
    -- This is the list of the base accounts in a balance sheet, but the sign is separate, so the order
    -- of these accounts is important. Later we might create a more general config for this, but this base
    -- account structure is unlikely to change in the short term.
    -- If you add an account to this, you also need to call gl.summarize() to include it in the report.
    _bases gl.account_k[] = array[(gl.settings(_team_k)).assets, (gl.settings(_team_k)).liabilities];

begin
    -- Include the assets
    create temp table bs as
    select account.name, summarize.* from gl.summarize(_team_k, _currency, _depth, false, _bases[1], 1)
                                              join gl.account using (team, account);

    -- Include liabilities
    insert into bs
    select account.name, summarize.* from gl.summarize(_team_k, _currency, _depth, false, _bases[2], -1)
                                              join gl.account using (team, account);

    -- Insert all the parent accounts. This could certainly be improved.
    insert into bs (team, account, name, parents, currency)
    select account.team, account.account, account.name, account.parents, _currency
        from gl.account
        where
                account.team = _team_k and
                account.parents[1] = any(_bases) and
                account.parents not in (select parents from bs) and
                array_length(account.parents, 1) <= _depth;

    -- Format nicely and return in correct order.
    return query
        select bs.team, bs.account, bs.name, array_length(bs.parents, 1), bs.currency, bs.amount
            from bs order by parents;

    drop table bs;
end;
$$;