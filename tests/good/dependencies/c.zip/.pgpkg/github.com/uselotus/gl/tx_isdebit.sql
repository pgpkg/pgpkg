--
-- This is the canonical function for determining if a transaction is a credit or a debit, based
-- on the type of the transaction. This function must be updated if a new tx_type enum is added.
-- A tx_type enum that is not known will result in an exception.
--
-- select gl.tx_isdebit('invoice') returns true.
--
create or replace function gl.tx_isdebit(_tx_type gl.tx_type_e) returns boolean immutable language plpgsql as $$
    begin
        case _tx_type
            when 'invoice', 'debit' then
                return true;

            when 'receipt', 'credit' then
                return false;

            else
                raise exception 'Unknown tx type %', _tx_type;
        end case;
    end;
$$;