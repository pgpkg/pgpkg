--
-- Create a debtor, make some payments, allocate them.
--

create or replace function gl.test_allocate() returns void language plpgsql as $$
    declare
        _team_k gl.team_k;
        _debtor_k gl.account_k;
        _sales_k gl.account_k;
        _debit_1 gl.tx_k;
        _debit_2 gl.tx_k;
        _credit_k gl.tx_k;
        _payments_k gl.account_k;
        _debit1_entry gl.entry_k;
        _debit2_entry gl.entry_k;
        _credit_entry gl.entry_k;

    begin
        _team_k = gl.team_create('Test team');
        _debtor_k = gl.debtor_create(_team_k, 'Test debtor');
        _sales_k = gl.account_create(_team_k, (gl.settings(_team_k)).sales, 'Test Sale #1', 99991);
        _payments_k = gl.account_create(_team_k, 32000, 'Payments pending', 99992);

        -- Allocate a 110 credit to a 100 debit.
        _debit_1 = gl.debit_create(_team_k, _debtor_k, gl.currency('AUD'), 100, 'Test debit #1');
        _debit_2 = gl.debit_create(_team_k, _debtor_k, gl.currency('AUD'), 100, 'Test debit #2');
        _credit_k = gl.credit_create(_team_k, _debtor_k, gl.currency('AUD'), 110, 'Test credit');

        select entry into strict _debit1_entry from gl.entry join gl.tx using (team, tx, account) where account=_debtor_k and team=_team_k and tx = _debit_1;
        select entry into strict _debit2_entry from gl.entry join gl.tx using (team, tx, account) where account=_debtor_k and team=_team_k and tx = _debit_2;
        select entry into strict _credit_entry from gl.entry join gl.tx using (team, tx, account) where account=_debtor_k and team=_team_k and tx_type='credit';

        --
        -- Have the unallocated amounts been created?
        --
        perform count(*) =? 3 from gl.unallocated where team = _team_k;
        perform amount =? 100 from gl.unallocated where team = _team_k and entry = _debit1_entry;
        perform amount =? 100 from gl.unallocated where team = _team_k and entry = _debit2_entry;
        perform amount =? -110 from gl.unallocated where team = _team_k and entry = _credit_entry;

        --
        -- Perform an allocation; this should return with -10 as the remaining amount.
        --
        perform gl.allocate(_team_k, _credit_entry, _debit1_entry) =? -10;
        perform gl.allocate(_team_k, _credit_entry, _debit2_entry) =? 0;
    end;
$$;