--
-- Creates a bunch of transactions for a variety of debtors, dates, teams and currencies, and then checks
-- that they summarise properly in the balance sheet.
--
-- This is the most complex of the tests (so far anyway) because it creates entries across multiple dimensions:
-- multiple teams, currencies and debtors. So in addition to ensuring that the reports give the right results,
-- this test also creates a situation where any "leaks" between teams, currencies or debtors should show up.
--
-- So, we are setting out to verify not only that the amounts add up as expected, but also that they
-- don't add up across teams or currencies.
--

create or replace function gl.add_balance_sheet_debtor(_team_k gl.team_k, _tax_k gl.account_k) returns void language plpgsql as $$
    declare
        _rounding_k gl.account_k = 13004; -- this is hard coded for now.
        _receivables_k gl.account_k = (gl.settings(_team_k)).receivables;
        _ar_depth integer = array_length(parents, 1) from gl.account where team = _team_k and account = _receivables_k;
        _tax_depth integer = array_length(parents, 1) from gl.account where team = _team_k and account = _tax_k;
        _rnd_depth integer = array_length(parents, 1) from gl.account where team = _team_k and account = _rounding_k;
        _debtor_1 gl.account_k;
        _debtor_2 gl.account_k;

    begin
        _debtor_1 = gl.debtor_create(_team_k, 'Test debtor #1');
        _debtor_2 = gl.debtor_create(_team_k, 'Test debtor #2');

        perform gl.create_test_transactions(_team_k, _debtor_1, _tax_k, gl.currency('AUD'), '2023-03-22 11:19:05.446787+10'::timestamptz);
        perform gl.create_test_transactions(_team_k, _debtor_2, _tax_k, gl.currency('AUD'), '2023-03-22 11:19:05.446787+10'::timestamptz);
        perform gl.create_test_transactions(_team_k, _debtor_1, _tax_k, gl.currency('USD'), '2023-03-22 11:19:05.446787+10'::timestamptz);
        perform gl.create_test_transactions(_team_k, _debtor_2, _tax_k, gl.currency('USD'), '2023-03-22 11:19:05.446787+10'::timestamptz);

        --
        -- Note: we need to know the total value of receivables, not the value for individual debtors, so we restrict the reporting depth to
        -- the receivables depth. Same goes for tax and rounding, but these won't have sub-transactions in any case so it's a bit academic.
        --

        -- AUD checks
        perform amount =? 449.40 from gl.balance_sheet(_team_k, gl.currency('AUD'), _ar_depth) where team=_team_k and account=_receivables_k;
        perform amount =? 49.3824 from gl.balance_sheet(_team_k, gl.currency('AUD'), _tax_depth) where team=_team_k and account=_tax_k;
        perform amount =? -0.0176 from gl.balance_sheet(_team_k, gl.currency('AUD'), _rnd_depth) where team=_team_k and account=_rounding_k; -- item rounding

        -- USD checks
        perform amount =? 449.40 from gl.balance_sheet(_team_k, gl.currency('USD'), _ar_depth) where team=_team_k and account=_receivables_k;
        perform amount =? 49.3824 from gl.balance_sheet(_team_k, gl.currency('USD'), _tax_depth) where team=_team_k and account=_tax_k;
        perform amount =? -0.0176 from gl.balance_sheet(_team_k, gl.currency('USD'), _rnd_depth) where team=_team_k and account=_rounding_k; -- item rounding
    end;
$$;

--
-- Add a team and perform the balance sheet tests.
--
create or replace function gl.add_balance_sheet_team() returns void language plpgsql as $$
    declare
        _team_k gl.team_k;
        _tax_k gl.account_k;

    begin
        _team_k = gl.team_create('Test team');
        _tax_k = gl.account_create(_team_k, (gl.settings(_team_k)).liabilities, 'Test Tax', 99992);
        perform gl.add_balance_sheet_debtor(_team_k, _tax_k);
    end;
$$;

--
-- Perform the balance sheet tests across three teams.
--
create or replace function gl.test_balance_sheet() returns void language plpgsql as $$
    begin
        perform gl.add_balance_sheet_team();
        perform gl.add_balance_sheet_team();
        perform gl.add_balance_sheet_team();
    end;
$$;