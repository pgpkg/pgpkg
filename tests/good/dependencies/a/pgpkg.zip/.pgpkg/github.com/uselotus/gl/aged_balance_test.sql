--
-- Creates a bunch of transactions for a variety of debtors, dates, teams and currencies, and then checks
-- that the aged balances are correct.
--
-- We are setting out to verify not only that the amounts add up as expected, but also that they
-- don't add up across teams or currencies.
--

create or replace function gl.add_aged_debtor(_team_k gl.team_k, _tax_k gl.account_k) returns void language plpgsql as $$
declare
    _debtor_1 gl.account_k;
    _debtor_2 gl.account_k;
    _since timestamptz = '2023-03-22 11:19:05.446787+10'::timestamptz;

begin
    _debtor_1 = gl.debtor_create(_team_k, 'Test debtor #1');
    _debtor_2 = gl.debtor_create(_team_k, 'Test debtor #2');

    perform gl.create_test_transactions(_team_k, _debtor_1, _tax_k, gl.currency('AUD'), _since);
    perform gl.create_test_transactions(_team_k, _debtor_2, _tax_k, gl.currency('AUD'), _since);
    perform gl.create_test_transactions(_team_k, _debtor_1, _tax_k, gl.currency('USD'), _since);
    perform gl.create_test_transactions(_team_k, _debtor_2, _tax_k, gl.currency('USD'), _since);

    perform amount =? 0, count =? 2, currency =? 523 from gl.aged_balance(_team_k, gl.currency('AUD'), _debtor_1, _since) where age = 0;
    perform amount =? 0, count =? 2, currency =? 523 from gl.aged_balance(_team_k, gl.currency('AUD'), _debtor_1, _since) where age = 30;
    perform amount =? 112.35, count =? 1, currency =? 523 from gl.aged_balance(_team_k, gl.currency('AUD'), _debtor_1, _since) where age = 60;
    perform amount =? 112.35, count =? 1, currency =? 523 from gl.aged_balance(_team_k, gl.currency('AUD'), _debtor_1, _since) where age = 90;

    perform amount =? 0, count =? 2, currency =? 13991 from gl.aged_balance(_team_k, gl.currency('USD'), _debtor_1, _since) where age = 0;
    perform amount =? 0, count =? 2, currency =? 13991 from gl.aged_balance(_team_k, gl.currency('USD'), _debtor_1, _since) where age = 30;
    perform amount =? 112.35, count =? 1, currency =? 13991 from gl.aged_balance(_team_k, gl.currency('USD'), _debtor_1, _since) where age = 60;
    perform amount =? 112.35, count =? 1, currency =? 13991 from gl.aged_balance(_team_k, gl.currency('USD'), _debtor_1, _since) where age = 90;
end;
$$;

--
-- Adds test transactions for a specific team.
-- We run the tests across multiple teams (cumulatively) to ensure they don't interfere
-- with one another.
--
create or replace function gl.add_aged_balance_team() returns void language plpgsql as $$
declare
    _team_k gl.team_k;
    _tax_k gl.account_k;
    _since timestamptz = '2023-03-22 11:19:05.446787+10'::timestamptz;

begin
    _team_k = gl.team_create('Test team');
    _tax_k = gl.account_create(_team_k, (gl.settings(_team_k)).liabilities, 'Test Tax', 99992);
    perform gl.add_aged_debtor(_team_k, _tax_k);

    -- Tests that the null-debtor version of aged_balance works. This returns all debtors, rather than
    -- just one debtor.
    perform sum(amount) =? 449.40, sum(count) =? 12 from gl.aged_balance(_team_k, gl.currency('USD'), null, _since);
    perform sum(amount) =? 449.40, sum(count) =? 12 from gl.aged_balance(_team_k, gl.currency('AUD'), null, _since);
end;
$$;

--
-- Perform the tests. The tests run against multiple teams, debtors and currencies.
--
create or replace function gl.test_aged_balance() returns void language plpgsql as $$
    begin
        perform gl.add_aged_balance_team();
        perform gl.add_aged_balance_team();
        perform gl.add_aged_balance_team();
    end;
$$;