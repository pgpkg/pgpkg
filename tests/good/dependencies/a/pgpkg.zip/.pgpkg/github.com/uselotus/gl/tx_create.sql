--
-- Create a tx record and return its ID.
--
create or replace function gl.tx_create(_team gl.team_k, _tx_type gl.tx_type_e, _account gl.account_k, _currency gl.currency_t, _effective_time timestamptz default current_timestamp, _tx_k uuid default gen_random_uuid()) returns gl.tx_k language sql as $$
    insert into gl.tx (team, tx, tx_type, account, currency, effective_time) values (_team, _tx_k, _tx_type, _account, _currency, _effective_time) returning tx;
$$;