--
-- Test that credit notes work.
--

create or replace function gl.test_credit_create_adjustment() returns void language plpgsql as $$
    declare
        _team_k gl.team_k;
        _debtor_k gl.account_k;
        _message text;
        _credit_k gl.tx_k;
        _tax_k gl.account_k;

    begin
        _team_k = gl.team_create('Test team');
        _debtor_k = gl.debtor_create(_team_k, 'Test Creditor #1');
        _message = 'Test credit #' || _debtor_k;
        _tax_k = gl.account_create(_team_k, (gl.settings(_team_k)).liabilities, 'Test Tax #1', 99992);

        -- create a credit that incorporates an adjustment, e.g. to cancel tax on an invoice.
        _credit_k = gl.credit_create(_team_k, _debtor_k, gl.currency('AUD'), 100.0, _message, null, array[(_tax_k, 5.123456)]::gl.adjustment_t[]);

        -- debtor's balance should be in credit.
        perform count(*) =? 1, coalesce(sum(amount), 0) =? -105.12 from gl.aged_balance(_team_k, gl.currency('AUD'), _debtor_k);

        -- exactly one entry in receivables...
        perform gl.currency(currency) =? 'AUD', amount =? -105.12 from gl.entry where team=_team_k and account=_debtor_k;

        -- ...one more in the credit account
        perform gl.currency(currency) =? 'AUD', amount =? 100 from gl.entry where team=_team_k and account=((gl.settings(_team_k)).credits);

        -- an entry in the tax account.
        perform gl.currency(currency) =? 'AUD', amount =? 5.123456 from gl.entry where team=_team_k and account=_tax_k;

        -- ...and one item against the transaction, with the right message.
        perform amount =? 105.12, message.message =? _message strict from gl.item
            join gl.message on (message.team = item.team and message.hash = item.description)
            where item.team=_team_k and tx=_credit_k;
    end;
$$;