--
-- Test that credit notes work.
--

create or replace function gl.test_receipt_create() returns void language plpgsql as $$
    declare
        _team_k gl.team_k;
        _debtor_k gl.account_k;
        _message text;
        _credit_k gl.tx_k;

    begin
        _team_k = gl.team_create('Test team');
        _debtor_k = gl.debtor_create(_team_k, 'Test Creditor #1');
        _message = 'Payment #' || _debtor_k;
        _credit_k = gl.receipt_create(_team_k, _debtor_k, 32100, gl.currency('AUD'), 100.0, _message);

        -- debtor's balance should be in credit.
        perform count(*) =? 1, coalesce(sum(amount), 0) =? -100 from gl.aged_balance(_team_k, gl.currency('AUD'), _debtor_k);

        -- exactly one entry in receivables...
        perform gl.currency(currency) =? 'AUD', amount =? -100 from gl.entry where team=_team_k and account=_debtor_k;

        -- ...and one more in the credit account
        perform gl.currency(currency) =? 'AUD', amount =? 100 from gl.entry where team=_team_k and account=32100;

        -- ...and one item against the transaction, with the right message.
        perform amount =? 100, message.message =? _message strict from gl.item
            join gl.message on (message.team = item.team and message.hash = item.description)
            where item.team=_team_k and tx=_credit_k;
    end;
$$;