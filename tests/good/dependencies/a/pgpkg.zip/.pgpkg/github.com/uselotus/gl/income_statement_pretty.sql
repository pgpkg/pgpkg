--
-- Generates a preformatted income statememt.
-- You can print it using this command:
--
--      select name, reporting_period, amount from gl.income_statement_pretty(:'team'::gl.team_k, gl.currency('USD'), 3) \crosstabview
--
create or replace function gl.income_statement_pretty(_team_k gl.team_k, _currency gl.currency_t, _depth integer)
    returns table (name text, reporting_period date, currency text, amount decimal) language sql as $$
    select gl.account_pretty(account) || ' ' || lpad('', depth * 2 - 2) || name, reporting_period, gl.currency(currency), amount from gl.income_statement(_team_k, _currency, _depth);
$$;