--
-- Create a well-defined set of transactions over a period of time, for the given debtor and currency.
-- This function is used by balance sheet and income statement report tests.
--
create or replace function gl.create_test_transactions(_team_k gl.team_k, _debtor_k gl.account_k, _tax_k gl.account_k, _currency gl.currency_t, _since timestamptz) returns void language plpgsql as $$
declare
    nowish timestamptz = _since;

begin
    perform gl.debit_create(_team_k, _debtor_k, _currency, 100.0, 'Test debit #1', nowish - '3 month'::interval, array[(_tax_k, 12.3456)]::gl.adjustment_t[]);
    perform gl.debit_create(_team_k, _debtor_k, _currency, 100.0, 'Test debit #1', nowish - '2 month'::interval, array[(_tax_k, 12.3456)]::gl.adjustment_t[]);

    perform gl.debit_create(_team_k, _debtor_k, _currency, 100.0, 'Test debit #1', nowish - '1 month'::interval, array[(_tax_k, 12.3456)]::gl.adjustment_t[]);
    perform gl.credit_create(_team_k, _debtor_k, _currency, 100.0, 'Test debit #1', nowish - '1 month'::interval, array[(_tax_k, 12.3456)]::gl.adjustment_t[]);

    perform gl.debit_create(_team_k, _debtor_k, _currency, 100.0, 'Test debit #1', nowish, array[(_tax_k, 12.3456)]::gl.adjustment_t[]);
    perform gl.credit_create(_team_k, _debtor_k, _currency, 100.0, 'Test debit #1', nowish, array[(_tax_k, 12.3456)]::gl.adjustment_t[]);
end;
$$;