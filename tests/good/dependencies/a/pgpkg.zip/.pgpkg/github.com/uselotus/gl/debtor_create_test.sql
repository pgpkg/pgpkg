--
-- This is actually about testing the account number returned by debtor-create.
--
create or replace function gl.test_debtor_create_number() returns void language plpgsql as $$
    declare
        _team_k gl.team_k;
        _debtor_k gl.account_k;
        _parent gl.account_k;
        _receivables text;

    begin
        _team_k = gl.team_create('Test team');
        _receivables = receivables::text from gl.settings(_team_k);

        -- Create a debtor against the regular receivables account.
        _debtor_k = gl.debtor_create(_team_k, 'Test debtor #1');
        perform ??(_debtor_k::text ~ (_receivables || '[0-9]{8}'));
        perform ??(open_item) from gl.account where team=_team_k and account = _debtor_k;

        -- The default receivables account is 31000, which means we can't tell if the 000 is included in the
        -- resulting debtor's account number. To remedy this we create our own account.
        -- Start with a typical 5-digit account number
        _parent = gl.account_create(_team_k, (gl.settings(_team_k)).income, 'Test Account', 12345);
        _debtor_k = gl.debtor_create(_team_k, 'Test debtor #2', _parent);
        perform ??(_debtor_k::text ~ '12345[0-9]{8}');

        --
        -- now repeat with 6-digit account number
        --
        _parent = gl.account_create(_team_k, (gl.settings(_team_k)).income, 'Test Account', 123456);
        _debtor_k = gl.debtor_create(_team_k, 'Test debtor #3', _parent);
        perform ??(_debtor_k::text ~ '123456[0-9]{8}');

    end;
$$;